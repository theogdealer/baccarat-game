"""Shoe, single-hand play and whole-shoe simulation."""
import random
from collections import deque
from dataclasses import dataclass
from typing import Deque, Iterable, Iterator, List, Optional, Tuple

from .cards import Card, card_value, create_cards, hand_total, shuffle_cards
from .rules import banker_draws, decide_winner, is_natural, player_draws

# A hand never needs more than 6 cards (2 + 2 + one third card each).
MAX_CARDS_PER_HAND = 6

# Casino burn procedure: the exposed card's rank says how many MORE cards to burn.
ADDITIONAL_BURN_BY_RANK = {
    "A": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9,
    "10": 10, "J": 10, "Q": 10, "K": 10,
}


class Shoe:
    """Cards are removed from the shoe as they are dealt and never reused."""

    def __init__(self, cards: Iterable[Card]) -> None:
        self._cards: Deque[Card] = deque(cards)
        self.dealt: List[Card] = []
        self.burned: List[Card] = []  # exposed burn card first, then the rest

    @classmethod
    def new_shuffled(cls, rng: random.Random) -> "Shoe":
        cards = create_cards()
        shuffle_cards(cards, rng)
        return cls(cards)

    @property
    def remaining(self) -> int:
        return len(self._cards)

    def can_deal_hand(self) -> bool:
        return self.remaining >= MAX_CARDS_PER_HAND

    def deal(self) -> Card:
        card = self._cards.popleft()
        self.dealt.append(card)
        return card

    def burn(self) -> Card:
        """Remove the top card as a burn card (it can never be dealt)."""
        card = self._cards.popleft()
        self.burned.append(card)
        return card


@dataclass(frozen=True)
class BurnInfo:
    exposed: Card                    # the revealed burn card
    additional: Tuple[Card, ...]     # extra cards burned because of its rank

    @property
    def additional_count(self) -> int:
        return len(self.additional)

    @property
    def total_burned(self) -> int:
        return 1 + len(self.additional)  # the exposed card is burned too


def burn_cards(shoe: Shoe) -> BurnInfo:
    """Burn procedure, run once per shoe before the first hand.

    1. Take the top card and expose it (it is removed from the shoe).
    2. Remove as many MORE cards as its rank dictates (A=1, 2-9=face value,
       10/J/Q/K=10). Example: exposed 6 -> 1 + 6 = 7 cards burned in total.
    """
    exposed = shoe.burn()
    extra = tuple(shoe.burn() for _ in range(ADDITIONAL_BURN_BY_RANK[exposed.rank]))
    return BurnInfo(exposed, extra)


@dataclass(frozen=True)
class HandResult:
    hand_number: int
    player_initial: Tuple[Card, Card]
    banker_initial: Tuple[Card, Card]
    player_third: Optional[Card]
    banker_third: Optional[Card]
    player_total: int
    banker_total: int
    result: str  # "B", "P" or "T"
    cards_remaining: int


def play_hand(shoe: Shoe, hand_number: int) -> HandResult:
    """Deal one complete hand using standard Punto Banco rules."""
    # Initial deal order: Player, Banker, Player, Banker.
    p1, b1, p2, b2 = shoe.deal(), shoe.deal(), shoe.deal(), shoe.deal()
    player_cards = [p1, p2]
    banker_cards = [b1, b2]
    player_third: Optional[Card] = None
    banker_third: Optional[Card] = None

    # A natural (8 or 9 on either side) means nobody draws.
    if not is_natural(hand_total(player_cards), hand_total(banker_cards)):
        player_third_value: Optional[int] = None
        if player_draws(hand_total(player_cards)):
            player_third = shoe.deal()
            player_cards.append(player_third)
            player_third_value = card_value(player_third)
        if banker_draws(hand_total(banker_cards), player_third_value):
            banker_third = shoe.deal()
            banker_cards.append(banker_third)

    p_total, b_total = hand_total(player_cards), hand_total(banker_cards)
    return HandResult(
        hand_number=hand_number,
        player_initial=(p1, p2),
        banker_initial=(b1, b2),
        player_third=player_third,
        banker_third=banker_third,
        player_total=p_total,
        banker_total=b_total,
        result=decide_winner(p_total, b_total),
        cards_remaining=shoe.remaining,
    )


def play_shoe(shoe: Shoe) -> Iterator[HandResult]:
    """Yield hands one at a time (a strategy engine can consume .result)."""
    hand_number = 1
    while shoe.can_deal_hand():  # stop when a full hand can't be guaranteed
        yield play_hand(shoe, hand_number)
        hand_number += 1


@dataclass(frozen=True)
class ShoeSimulation:
    burn: BurnInfo
    hands: List[HandResult]


def simulate_shoe_with_burn(rng: Optional[random.Random] = None) -> ShoeSimulation:
    """Shuffle a fresh shoe, burn cards once, then play it to the end."""
    if rng is None:
        rng = random.SystemRandom()  # type: ignore[assignment]
    shoe = Shoe.new_shuffled(rng)  # type: ignore[arg-type]
    burn = burn_cards(shoe)
    return ShoeSimulation(burn, list(play_shoe(shoe)))


def simulate_shoe(rng: Optional[random.Random] = None) -> List[HandResult]:
    """Same as simulate_shoe_with_burn but returns only the hands."""
    return simulate_shoe_with_burn(rng).hands
