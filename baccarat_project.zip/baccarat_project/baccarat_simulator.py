"""Run with:  python baccarat_simulator.py"""
from baccarat.cli import main

if __name__ == "__main__":
    main()
