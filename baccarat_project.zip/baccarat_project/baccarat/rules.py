"""Pure Punto Banco drawing rules (no cards or shoe needed, easy to test)."""
from typing import Optional

NATURAL_MINIMUM = 8


def is_natural(player_total: int, banker_total: int) -> bool:
    """Either side holding 8 or 9 after the initial deal ends the hand."""
    return player_total >= NATURAL_MINIMUM or banker_total >= NATURAL_MINIMUM


def player_draws(player_total: int) -> bool:
    """Player draws on 0-5 and stands on 6-7."""
    return player_total <= 5


def banker_draws(banker_total: int, player_third_value: Optional[int]) -> bool:
    """Banker drawing rule.

    player_third_value is the Baccarat VALUE (0-9) of the Player's third card,
    or None if the Player stood.
    """
    if player_third_value is None:
        # Player stood: Banker draws on 0-5, stands on 6-7.
        return banker_total <= 5
    # Player drew: standard third-card table.
    if banker_total <= 2:
        return True
    if banker_total == 3:
        return player_third_value != 8
    if banker_total == 4:
        return 2 <= player_third_value <= 7
    if banker_total == 5:
        return 4 <= player_third_value <= 7
    if banker_total == 6:
        return 6 <= player_third_value <= 7
    return False  # Banker 7 always stands


def decide_winner(player_total: int, banker_total: int) -> str:
    """Return 'P', 'B' or 'T' from the final totals."""
    if player_total > banker_total:
        return "P"
    if banker_total > player_total:
        return "B"
    return "T"
