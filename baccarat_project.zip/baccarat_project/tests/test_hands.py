import unittest

from baccarat.rules import banker_draws, decide_winner, player_draws
from baccarat.shoe import play_hand
from .helpers import make_shoe

# Independently written Banker table: banker total -> player third values that DRAW.
ALL = set(range(10))
BANKER_DRAWS_ON = {0: ALL, 1: ALL, 2: ALL, 3: ALL - {8}, 4: set(range(2, 8)),
                   5: set(range(4, 8)), 6: {6, 7}, 7: set()}


def rank_for_value(v):
    return {0: "K", 1: "A"}.get(v, str(v))


class NaturalTests(unittest.TestCase):
    def test_player_natural_8_stops_everything(self):
        # P 3+5=8, B 2+2=4 (would draw otherwise)
        h = play_hand(make_shoe(["3", "2", "5", "2"]), 1)
        self.assertIsNone(h.player_third)
        self.assertIsNone(h.banker_third)
        self.assertEqual((h.player_total, h.banker_total, h.result), (8, 4, "P"))

    def test_banker_natural_9_stops_player_drawing_on_5(self):
        # P 2+3=5 (would draw), B 4+5=9
        h = play_hand(make_shoe(["2", "4", "3", "5"]), 1)
        self.assertIsNone(h.player_third)
        self.assertIsNone(h.banker_third)
        self.assertEqual((h.player_total, h.banker_total, h.result), (5, 9, "B"))

    def test_natural_tie(self):
        h = play_hand(make_shoe(["4", "9", "5", "K"]), 1)  # 9 v 9
        self.assertEqual(h.result, "T")


class PlayerRuleTests(unittest.TestCase):
    def test_player_draws_0_to_5_stands_6_7(self):
        for t in range(6):
            self.assertTrue(player_draws(t), t)
        for t in (6, 7):
            self.assertFalse(player_draws(t), t)

    def test_player_draws_third_card_in_hand(self):
        # P K+5=5 draws a 2 -> 7; B K+7=7 stands
        h = play_hand(make_shoe(["K", "K", "5", "7", "2"]), 1)
        self.assertEqual(str(h.player_third), "2S")
        self.assertIsNone(h.banker_third)
        self.assertEqual((h.player_total, h.banker_total, h.result), (7, 7, "T"))

    def test_player_stands_on_6_and_banker_draws_on_5_or_less(self):
        # P 3+3=6 stands; B K+2=2 draws a 4 -> 6 ; tie
        h = play_hand(make_shoe(["3", "K", "3", "2", "4"]), 1)
        self.assertIsNone(h.player_third)
        self.assertEqual(str(h.banker_third), "4S")
        self.assertEqual((h.player_total, h.banker_total, h.result), (6, 6, "T"))

    def test_banker_stands_on_6_and_7_when_player_stood(self):
        for banker_second, total in (("6", 6), ("7", 7)):
            h = play_hand(make_shoe(["4", "K", "3", banker_second]), 1)  # P=7 stands
            self.assertIsNone(h.banker_third)
            self.assertEqual(h.banker_total, total)

    def test_banker_draws_0_to_5_when_player_stood(self):
        for t in range(6):
            self.assertTrue(banker_draws(t, None), t)
        for t in (6, 7):
            self.assertFalse(banker_draws(t, None), t)


class BankerTableTests(unittest.TestCase):
    def test_banker_table_in_rules_function(self):
        for banker_total, draw_set in BANKER_DRAWS_ON.items():
            for v in range(10):
                self.assertEqual(banker_draws(banker_total, v), v in draw_set,
                                 f"banker {banker_total} vs player third {v}")

    def test_banker_table_through_full_hands(self):
        # Player K+K=0 always draws; banker K+t = t (0..7, never a natural).
        for banker_total in range(8):
            for v in range(10):
                banker_second = rank_for_value(banker_total)
                shoe = make_shoe(["K", "K", "K", banker_second, rank_for_value(v), "2"])
                h = play_hand(shoe, 1)
                self.assertEqual(h.banker_total if h.banker_third is None else None,
                                 banker_total if h.banker_third is None else None)
                self.assertEqual(h.banker_third is not None,
                                 v in BANKER_DRAWS_ON[banker_total],
                                 f"banker {banker_total} vs player third {v}")

    def test_banker_3_vs_player_third_8_exception(self):
        # P 2+3=5 draws 8 -> 3; B K+3=3 must STAND; the next card stays in the shoe
        shoe = make_shoe(["2", "K", "3", "3", "8", "9"], extra=0)
        h = play_hand(shoe, 1)
        self.assertIsNone(h.banker_third)
        self.assertEqual((h.player_total, h.banker_total, h.result), (3, 3, "T"))
        self.assertEqual(shoe.remaining, 1)

    def test_banker_3_draws_against_player_third_7(self):
        # P 2+3=5 draws 7 -> 2; B K+3=3 draws 9 -> 2... use 6 -> 9
        h = play_hand(make_shoe(["2", "K", "3", "3", "7", "6"]), 1)
        self.assertEqual(str(h.banker_third), "6S")
        self.assertEqual((h.player_total, h.banker_total, h.result), (2, 9, "B"))


class WinnerTests(unittest.TestCase):
    def test_winner(self):
        self.assertEqual(decide_winner(7, 6), "P")
        self.assertEqual(decide_winner(3, 9), "B")
        self.assertEqual(decide_winner(0, 0), "T")

    def test_tie_recorded_after_third_cards(self):
        # P 3+K=3 draws 4 -> 7; B 3+K=3, vs 4 draws 4 -> 7
        h = play_hand(make_shoe(["3", "3", "K", "K", "4", "4"]), 1)
        self.assertEqual((h.player_total, h.banker_total, h.result), (7, 7, "T"))

    def test_cards_remaining_recorded(self):
        shoe = make_shoe(["3", "2", "5", "2"], extra=10)
        h = play_hand(shoe, 1)
        self.assertEqual(h.cards_remaining, 10)


if __name__ == "__main__":
    unittest.main()
