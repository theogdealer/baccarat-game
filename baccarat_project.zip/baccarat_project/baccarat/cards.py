"""Deck creation, shuffling, card values and hand totals."""
import random
from dataclasses import dataclass
from typing import Iterable, List

RANKS = ("A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K")
SUITS = ("S", "H", "D", "C")  # Spades, Hearts, Diamonds, Clubs
NUMBER_OF_DECKS = 8
TOTAL_CARDS = NUMBER_OF_DECKS * 52  # 416


@dataclass(frozen=True)
class Card:
    deck: int   # 1..8, so every physical card is unique
    rank: str
    suit: str

    def __str__(self) -> str:
        return f"{self.rank}{self.suit}"


def create_cards(number_of_decks: int = NUMBER_OF_DECKS) -> List[Card]:
    """Create every physical card: 8 decks x 52 = 416 cards."""
    return [
        Card(deck, rank, suit)
        for deck in range(1, number_of_decks + 1)
        for suit in SUITS
        for rank in RANKS
    ]


def shuffle_cards(cards: List[Card], rng: random.Random) -> None:
    """Shuffle the cards in place using the supplied random generator."""
    rng.shuffle(cards)


def card_value(card: Card) -> int:
    """Baccarat value: Ace=1, 2-9 face value, 10/J/Q/K=0."""
    if card.rank == "A":
        return 1
    if card.rank in ("10", "J", "Q", "K"):
        return 0
    return int(card.rank)


def hand_total(cards: Iterable[Card]) -> int:
    """Baccarat total: sum of card values modulo 10."""
    return sum(card_value(c) for c in cards) % 10
