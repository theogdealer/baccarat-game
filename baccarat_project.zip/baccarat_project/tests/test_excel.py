import random
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

from openpyxl import Workbook, load_workbook

from baccarat.excel_export import export_shoe
from baccarat.shoe import simulate_shoe


class ExcelTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "Baccarat_Historical_Shoes.xlsx"

    def tearDown(self):
        self.tmp.cleanup()

    def column(self, ws, col):
        return [ws.cell(row=r, column=col).value for r in range(2, ws.max_row + 1)]

    def test_first_shoe_layout(self):
        hands = simulate_shoe(random.Random(1))
        self.assertEqual(export_shoe(hands, self.path), 1)
        ws = load_workbook(self.path)["Results"]
        self.assertEqual(ws["A1"].value, "Hand")
        self.assertEqual(ws["B1"].value, "Shoe 001")
        for n in range(1, 81):
            self.assertEqual(ws.cell(row=n + 1, column=1).value, n)
        for h in hands:  # stored vertically under the right column
            self.assertEqual(ws.cell(row=h.hand_number + 1, column=2).value, h.result)

    def test_unplayed_hands_are_empty_and_cells_are_bpt(self):
        hands = simulate_shoe(random.Random(2))
        export_shoe(hands, self.path)
        ws = load_workbook(self.path)["Results"]
        values = self.column(ws, 2)
        self.assertTrue(all(v in ("B", "P", "T") for v in values[:len(hands)]))
        self.assertTrue(all(v is None for v in values[len(hands):]))

    def test_existing_shoe_columns_are_preserved(self):
        first = simulate_shoe(random.Random(1))
        export_shoe(first, self.path)
        before = self.column(load_workbook(self.path)["Results"], 2)
        second = simulate_shoe(random.Random(2))
        self.assertEqual(export_shoe(second, self.path), 2)
        ws = load_workbook(self.path)["Results"]
        self.assertEqual(self.column(ws, 2)[:len(before)], before)
        self.assertEqual(ws["C1"].value, "Shoe 002")
        for h in second:
            self.assertEqual(ws.cell(row=h.hand_number + 1, column=3).value, h.result)

    def test_every_completed_shoe_is_exported(self):
        shoes = [simulate_shoe(random.Random(s)) for s in range(5)]
        for i, hands in enumerate(shoes, start=1):
            self.assertEqual(export_shoe(hands, self.path), i)
        wb = load_workbook(self.path)
        ws = wb["Results"]
        for i, hands in enumerate(shoes):
            self.assertEqual(ws.cell(row=1, column=i + 2).value, f"Shoe {i + 1:03d}")
            got = [ws.cell(row=r, column=i + 2).value for r in range(2, len(hands) + 2)]
            self.assertEqual(got, [h.result for h in hands])
        self.assertEqual(wb["Hand Details"].max_row - 1, sum(len(h) for h in shoes))

    def test_hand_details_content(self):
        hands = simulate_shoe(random.Random(3))
        export_shoe(hands, self.path)
        ws = load_workbook(self.path)["Hand Details"]
        h = hands[0]
        row = [c.value for c in ws[2]]
        self.assertEqual(row[0], 1)
        self.assertEqual(row[1], 1)
        self.assertEqual(row[2], str(h.player_initial[0]))
        self.assertEqual(row[10], h.result)
        self.assertEqual(row[11], h.cards_remaining)

    def test_existing_hand_labels_and_numbering_continue_from_manual_workbook(self):
        wb = Workbook()
        ws = wb.active
        ws.title = "Results"
        ws["A1"], ws["B1"], ws["C1"] = "Hand", "Shoe 001", "Shoe 005"
        ws["B2"], ws["C2"] = "B", "P"
        wb.save(self.path)
        self.assertEqual(export_shoe(simulate_shoe(random.Random(4)), self.path), 6)
        ws = load_workbook(self.path)["Results"]
        self.assertEqual((ws["B2"].value, ws["C2"].value), ("B", "P"))
        self.assertEqual(ws["D1"].value, "Shoe 006")

    def test_long_shoe_extends_rows_beyond_80(self):
        base = simulate_shoe(random.Random(1))
        hands = [replace(base[n % len(base)], hand_number=n + 1) for n in range(86)]
        export_shoe(hands, self.path)
        ws = load_workbook(self.path)["Results"]
        for n in range(1, 87):
            self.assertEqual(ws.cell(row=n + 1, column=1).value, n)
            self.assertEqual(ws.cell(row=n + 1, column=2).value, hands[n - 1].result)


if __name__ == "__main__":
    unittest.main()
