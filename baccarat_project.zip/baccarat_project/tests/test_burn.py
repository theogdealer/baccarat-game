import random
import tempfile
import unittest
from pathlib import Path

from openpyxl import load_workbook

from baccarat.cards import RANKS, TOTAL_CARDS, Card, create_cards, shuffle_cards
from baccarat.excel_export import export_shoe
from baccarat.shoe import (Shoe, burn_cards, play_shoe, simulate_shoe,
                           simulate_shoe_with_burn)

EXPECTED = {"A": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7, "8": 8,
            "9": 9, "10": 10, "J": 10, "Q": 10, "K": 10}


def scripted_shoe(exposed_rank, filler=30):
    """Exposed card on top, then uniquely identifiable filler cards (deck 2)."""
    cards = [Card(1, exposed_rank, "H")]
    cards += [Card(2, "9", f"F{i}") for i in range(filler)]
    return Shoe(cards), cards


class BurnCountTests(unittest.TestCase):
    def check(self, rank):
        shoe, cards = scripted_shoe(rank)
        burn = burn_cards(shoe)
        n = EXPECTED[rank]
        self.assertEqual(burn.additional_count, n)
        self.assertEqual(burn.total_burned, n + 1)       # exposed card is extra
        self.assertEqual(shoe.remaining, len(cards) - n - 1)
        self.assertEqual(burn.exposed, cards[0])
        self.assertEqual(list(burn.additional), cards[1:n + 1])

    def test_ace_burns_one(self):
        self.check("A")

    def test_two_burns_two(self):
        self.check("2")

    def test_six_burns_six(self):
        self.check("6")

    def test_nine_burns_nine(self):
        self.check("9")

    def test_ten_burns_ten(self):
        self.check("10")

    def test_face_cards_burn_ten(self):
        for rank in ("J", "Q", "K"):
            self.check(rank)

    def test_every_rank(self):
        for rank in RANKS:
            self.check(rank)

    def test_six_of_hearts_burns_seven_total(self):
        shoe, _ = scripted_shoe("6")
        self.assertEqual(burn_cards(shoe).total_burned, 7)

    def test_exposed_card_is_removed_from_shoe(self):
        shoe, cards = scripted_shoe("A")
        burn_cards(shoe)
        self.assertEqual(shoe.remaining, len(cards) - 2)   # exposed + 1 more
        self.assertEqual(shoe.deal(), cards[2])            # first dealt card follows
        self.assertNotIn(cards[0], shoe.dealt)


class BurnIntegrationTests(unittest.TestCase):
    def test_burned_cards_never_dealt_and_accounting_is_416(self):
        for seed in range(40):
            sim = simulate_shoe_with_burn(random.Random(seed))
            burned = [sim.burn.exposed] + list(sim.burn.additional)
            dealt = []
            for h in sim.hands:
                dealt += list(h.player_initial) + list(h.banker_initial)
                dealt += [c for c in (h.player_third, h.banker_third) if c]
            self.assertFalse(set(burned) & set(dealt))
            self.assertEqual(len(burned) + len(dealt) + sim.hands[-1].cards_remaining,
                             TOTAL_CARDS)

    def test_remaining_count_reflects_burn_on_first_hand(self):
        sim = simulate_shoe_with_burn(random.Random(11))
        h = sim.hands[0]
        used = 4 + (h.player_third is not None) + (h.banker_third is not None)
        self.assertEqual(h.cards_remaining, TOTAL_CARDS - sim.burn.total_burned - used)

    def test_burn_not_repeated_between_hands(self):
        cards = create_cards()
        shuffle_cards(cards, random.Random(3))
        shoe = Shoe(cards)
        burn = burn_cards(shoe)
        burned_after_burn = list(shoe.burned)
        hands = list(play_shoe(shoe))
        self.assertEqual(shoe.burned, burned_after_burn)       # untouched by play
        self.assertEqual(len(shoe.burned), burn.total_burned)  # exactly one procedure
        self.assertEqual(len(shoe.dealt) + len(shoe.burned) + shoe.remaining, TOTAL_CARDS)
        self.assertGreater(len(hands), 60)

    def test_each_new_shoe_gets_its_own_burn(self):
        rng = random.Random(99)
        for _ in range(5):
            state = rng.getstate()
            sim = simulate_shoe_with_burn(rng)
            # Rebuild the same shuffle independently and check its top cards.
            cards = create_cards()
            shuffle_cards(cards, _rng_from_state(state))
            self.assertEqual(sim.burn.exposed, cards[0])
            n = EXPECTED[cards[0].rank]
            self.assertEqual(list(sim.burn.additional), cards[1:n + 1])

    def test_seeded_simulation_reproducible_including_burn(self):
        a = simulate_shoe_with_burn(random.Random(2024))
        b = simulate_shoe_with_burn(random.Random(2024))
        self.assertEqual(a, b)
        self.assertEqual(simulate_shoe(random.Random(2024)), a.hands)


def _rng_from_state(state):
    r = random.Random()
    r.setstate(state)
    return r


class BurnExcelTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "Baccarat_Historical_Shoes.xlsx"

    def tearDown(self):
        self.tmp.cleanup()

    def test_burn_information_exported(self):
        sims = [simulate_shoe_with_burn(random.Random(s)) for s in (1, 2, 3)]
        for i, sim in enumerate(sims, start=1):
            self.assertEqual(export_shoe(sim.hands, self.path, sim.burn), i)
        wb = load_workbook(self.path)
        self.assertEqual(wb.sheetnames, ["Results", "Hand Details", "Shoe Summary"])
        ws = wb["Shoe Summary"]
        self.assertEqual([c.value for c in ws[1]],
                         ["Shoe", "Burn Rank", "Burn Suit", "Additional Cards Burned",
                          "Total Cards Burned", "Hands Dealt", "Remaining Cards"])
        for i, sim in enumerate(sims, start=1):
            row = [c.value for c in ws[i + 1]]
            self.assertEqual(row, [i, sim.burn.exposed.rank, sim.burn.exposed.suit,
                                   sim.burn.additional_count, sim.burn.total_burned,
                                   len(sim.hands), sim.hands[-1].cards_remaining])

    def test_existing_columns_and_layout_intact_with_burn(self):
        a = simulate_shoe_with_burn(random.Random(5))
        b = simulate_shoe_with_burn(random.Random(6))
        export_shoe(a.hands, self.path, a.burn)
        before = [load_workbook(self.path)["Results"].cell(row=r, column=2).value
                  for r in range(1, 90)]
        export_shoe(b.hands, self.path, b.burn)
        wb = load_workbook(self.path)
        ws = wb["Results"]
        self.assertEqual([ws.cell(row=r, column=2).value for r in range(1, 90)], before)
        self.assertEqual(ws["C1"].value, "Shoe 002")
        for h in b.hands:
            self.assertEqual(ws.cell(row=h.hand_number + 1, column=3).value, h.result)
        self.assertEqual(wb["Hand Details"]["A1"].value, "Shoe")
        self.assertEqual(wb["Hand Details"].max_row - 1, len(a.hands) + len(b.hands))

    def test_export_without_burn_still_works(self):
        export_shoe(simulate_shoe(random.Random(1)), self.path)
        self.assertEqual(load_workbook(self.path).sheetnames, ["Results", "Hand Details"])


if __name__ == "__main__":
    unittest.main()
