"""Eight-deck Baccarat shoe simulator (engine only: no betting, no strategy)."""
