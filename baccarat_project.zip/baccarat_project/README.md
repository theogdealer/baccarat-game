# Eight-Deck Baccarat Shoe Simulator

## Setup (Fedora)
    cd baccarat_project
    source /path/to/your/venv/bin/activate
    pip install openpyxl        # only if not already installed

## Run
    python baccarat_simulator.py

Menu: 1 = one shoe, 2 = multiple shoes, 3 = exit. You can enter an optional
seed (reproduces a shoe, or a whole multi-shoe run) and choose whether to print
the hand-by-hand summary. Results append to Baccarat_Historical_Shoes.xlsx in
the folder you run from.

## Tests
    python -m unittest -v

## Layout
    baccarat_simulator.py   entry point
    baccarat/cards.py       deck creation, shuffle, card values, totals
    baccarat/rules.py       Player/Banker drawing rules, winner
    baccarat/shoe.py        Shoe, play_hand, play_shoe (yields hands one by one), simulate_shoe
    baccarat/excel_export.py  Results + Hand Details export
    baccarat/cli.py         terminal menu
    tests/                  36 automated tests

## Strategy engine hook
    from baccarat.shoe import Shoe, play_shoe
    for hand in play_shoe(Shoe.new_shuffled(rng)):
        strategy.receive(hand.result)   # "B", "P" or "T"
