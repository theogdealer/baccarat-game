"""Terminal interface."""
import random
from typing import List, Optional

from .excel_export import WORKBOOK_NAME, export_shoe
from .cards import TOTAL_CARDS
from .shoe import BurnInfo, HandResult, simulate_shoe_with_burn


def format_hand(h: HandResult) -> str:
    def side(initial, third) -> str:
        cards = " ".join(str(c) for c in initial)
        return f"{cards} + {third}" if third else cards
    return (f"Hand {h.hand_number:>2}: Player [{side(h.player_initial, h.player_third):<12}] "
            f"{h.player_total} | Banker [{side(h.banker_initial, h.banker_third):<12}] "
            f"{h.banker_total} -> {h.result}  ({h.cards_remaining} cards left)")


def print_hand_summary(hands: List[HandResult]) -> None:
    for h in hands:
        print(format_hand(h))


def print_shoe_summary(shoe_number: int, hands: List[HandResult],
                       burn: Optional[BurnInfo] = None) -> None:
    print(f"\nShoe {shoe_number:03d}")
    if burn is not None:
        print(f"  Burn card: {burn.exposed} (+{burn.additional_count} more, "
              f"{burn.total_burned} cards burned)")
    print(f"  Total hands dealt: {len(hands)}")
    print(f"  Banker wins: {sum(h.result == 'B' for h in hands)}")
    print(f"  Player wins: {sum(h.result == 'P' for h in hands)}")
    print(f"  Ties:        {sum(h.result == 'T' for h in hands)}")
    print(f"  Remaining cards: {hands[-1].cards_remaining if hands else TOTAL_CARDS}")


def ask_seed() -> Optional[int]:
    while True:
        text = input("Optional seed (press Enter for random): ").strip()
        if not text:
            return None
        try:
            return int(text)
        except ValueError:
            print("Please enter a whole number or press Enter.")


def ask_count() -> int:
    while True:
        text = input("How many shoes? ").strip()
        if text.isdigit() and int(text) > 0:
            return int(text)
        print("Please enter a positive whole number.")


def run_shoes(count: int, seed: Optional[int], show_hands: bool) -> None:
    # One generator for the whole run: a seed reproduces the entire run.
    rng = random.Random(seed) if seed is not None else random.SystemRandom()
    for _ in range(count):
        sim = simulate_shoe_with_burn(rng)  # type: ignore[arg-type]
        hands = sim.hands
        try:
            shoe_number = export_shoe(hands, WORKBOOK_NAME, sim.burn)
        except OSError as error:
            print(f"Could not save {WORKBOOK_NAME}: {error}")
            return
        if show_hands:
            print()
            print_hand_summary(hands)
        print_shoe_summary(shoe_number, hands, sim.burn)
        print(f"  Saved to {WORKBOOK_NAME}")


def main() -> None:
    while True:
        print("\nBaccarat Shoe Simulator")
        print("1. Simulate one new eight-deck shoe")
        print("2. Simulate multiple shoes")
        print("3. Exit")
        choice = input("Choose 1-3: ").strip()
        if choice == "3":
            print("Goodbye.")
            return
        if choice not in ("1", "2"):
            print("Please choose 1, 2 or 3.")
            continue
        count = 1 if choice == "1" else ask_count()
        seed = ask_seed()
        show = input("Show hand-by-hand summary? (y/N): ").strip().lower() == "y"
        run_shoes(count, seed, show)
