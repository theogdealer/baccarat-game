"""Excel export. Never overwrites existing shoe columns."""
import os
import re
from pathlib import Path
from typing import List, Optional, Sequence, Union

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter

from .cards import TOTAL_CARDS
from .shoe import BurnInfo, HandResult

WORKBOOK_NAME = "Baccarat_Historical_Shoes.xlsx"
RESULTS_SHEET = "Results"
DETAILS_SHEET = "Hand Details"
SUMMARY_SHEET = "Shoe Summary"
STANDARD_HAND_ROWS = 80  # rows 2-81; extended automatically if a shoe runs longer
SHOE_HEADER = re.compile(r"^Shoe (\d+)$")
DETAIL_HEADERS = [
    "Shoe", "Hand", "Player Card 1", "Player Card 2", "Player Card 3",
    "Banker Card 1", "Banker Card 2", "Banker Card 3",
    "Player Total", "Banker Total", "Result", "Cards Remaining",
]


def _get_sheet(wb: Workbook, name: str):
    if name in wb.sheetnames:
        return wb[name]
    # A brand-new workbook has an empty default sheet: reuse it for Results.
    if name == RESULTS_SHEET and wb.sheetnames == ["Sheet"]:
        wb["Sheet"].title = name
        return wb[name]
    return wb.create_sheet(name)


def _next_shoe_slot(ws) -> "tuple[int, int]":
    """Return (shoe_number, column_index) for the next free shoe column."""
    last_column, highest_number = 1, 0
    for col in range(2, ws.max_column + 1):
        header = ws.cell(row=1, column=col).value
        if header is None or header == "":
            continue
        last_column = col
        match = SHOE_HEADER.match(str(header))
        if match:
            highest_number = max(highest_number, int(match.group(1)))
    return highest_number + 1, last_column + 1


def _ensure_hand_numbers(ws, hands_needed: int) -> None:
    ws.cell(row=1, column=1, value="Hand").font = Font(bold=True)
    for n in range(1, max(STANDARD_HAND_ROWS, hands_needed) + 1):
        if ws.cell(row=n + 1, column=1).value is None:
            ws.cell(row=n + 1, column=1, value=n)


def _write_results_column(ws, shoe_number: int, column: int, hands: Sequence[HandResult]) -> None:
    _ensure_hand_numbers(ws, len(hands))
    ws.cell(row=1, column=column, value=f"Shoe {shoe_number:03d}").font = Font(bold=True)
    for hand in hands:
        ws.cell(row=hand.hand_number + 1, column=column, value=hand.result)
    ws.column_dimensions[get_column_letter(column)].width = 10
    ws.freeze_panes = "B2"


def _append_details(ws, shoe_number: int, hands: Sequence[HandResult]) -> None:
    if ws["A1"].value is None:  # brand-new sheet: write the header row first
        for col, title in enumerate(DETAIL_HEADERS, start=1):
            ws.cell(row=1, column=col, value=title).font = Font(bold=True)
        ws.freeze_panes = "A2"
    for h in hands:
        def card(c):
            return str(c) if c is not None else None
        ws.append([
            shoe_number, h.hand_number,
            card(h.player_initial[0]), card(h.player_initial[1]), card(h.player_third),
            card(h.banker_initial[0]), card(h.banker_initial[1]), card(h.banker_third),
            h.player_total, h.banker_total, h.result, h.cards_remaining,
        ])


SUMMARY_HEADERS = [
    "Shoe", "Burn Rank", "Burn Suit", "Additional Cards Burned",
    "Total Cards Burned", "Hands Dealt", "Remaining Cards",
]


def _append_summary(ws, shoe_number: int, hands: Sequence[HandResult], burn: BurnInfo) -> None:
    if ws["A1"].value is None:
        for col, title in enumerate(SUMMARY_HEADERS, start=1):
            ws.cell(row=1, column=col, value=title).font = Font(bold=True)
        ws.freeze_panes = "A2"
    remaining = hands[-1].cards_remaining if hands else TOTAL_CARDS - burn.total_burned
    ws.append([shoe_number, burn.exposed.rank, burn.exposed.suit, burn.additional_count,
               burn.total_burned, len(hands), remaining])


def export_shoe(hands: Sequence[HandResult], path: Union[str, Path] = WORKBOOK_NAME,
                burn: Optional[BurnInfo] = None) -> int:
    """Append one completed shoe to the workbook and save. Returns its number.

    If burn info is given, a row is also added to the "Shoe Summary" sheet.
    """
    path = Path(path)
    wb = load_workbook(path) if path.exists() else Workbook()
    results = _get_sheet(wb, RESULTS_SHEET)
    details = _get_sheet(wb, DETAILS_SHEET)

    shoe_number, column = _next_shoe_slot(results)
    _write_results_column(results, shoe_number, column, hands)
    _append_details(details, shoe_number, hands)
    if burn is not None:
        _append_summary(_get_sheet(wb, SUMMARY_SHEET), shoe_number, hands, burn)

    # Save to a temp file first so a crash can't corrupt existing history.
    temp = path.with_name(path.name + ".tmp")
    wb.save(temp)
    os.replace(temp, path)
    return shoe_number
