from baccarat.cards import Card
from baccarat.shoe import Shoe


def make_shoe(ranks, extra=12):
    """Scripted shoe: cards are dealt in the order given (P1,B1,P2,B2,P3,B3...).
    Padding cards of rank 'K' follow so the shoe never runs dry."""
    cards = [Card(1, r, "S") for r in ranks] + [Card(2, "K", "H")] * extra
    return Shoe(cards)
