import random
import unittest

from baccarat.cards import Card, RANKS, card_value, create_cards, hand_total, shuffle_cards
from baccarat.shoe import Shoe, simulate_shoe_with_burn


class CardTests(unittest.TestCase):
    def test_eight_decks_have_416_cards(self):
        self.assertEqual(len(create_cards()), 416)

    def test_every_card_unique_by_deck_rank_suit(self):
        keys = {(c.deck, c.rank, c.suit) for c in create_cards()}
        self.assertEqual(len(keys), 416)

    def test_each_rank_appears_32_times(self):
        cards = create_cards()
        for rank in RANKS:
            self.assertEqual(sum(c.rank == rank for c in cards), 32)

    def test_shuffle_keeps_all_cards(self):
        cards = create_cards()
        shuffle_cards(cards, random.Random(1))
        self.assertEqual(len(set(cards)), 416)

    def test_card_values(self):
        expected = {"A": 1, "2": 2, "3": 3, "4": 4, "5": 5, "6": 6, "7": 7,
                    "8": 8, "9": 9, "10": 0, "J": 0, "Q": 0, "K": 0}
        for rank, value in expected.items():
            self.assertEqual(card_value(Card(1, rank, "S")), value, rank)

    def test_totals_are_modulo_10(self):
        def total(*ranks):
            return hand_total([Card(1, r, "S") for r in ranks])
        self.assertEqual(total("7", "8"), 5)        # 15 -> 5
        self.assertEqual(total("9", "9"), 8)        # 18 -> 8
        self.assertEqual(total("K", "Q"), 0)
        self.assertEqual(total("5", "5"), 0)        # 10 -> 0
        self.assertEqual(total("9", "9", "9"), 7)   # 27 -> 7
        self.assertEqual(total("A", "9"), 0)

    def test_cards_never_reused_in_a_shoe(self):
        shoe = Shoe.new_shuffled(random.Random(7))
        seen = []
        while shoe.remaining:
            seen.append(shoe.deal())
        self.assertEqual(len(seen), 416)
        self.assertEqual(len(set(seen)), 416)

    def test_dealing_removes_cards(self):
        shoe = Shoe.new_shuffled(random.Random(7))
        shoe.deal()
        shoe.deal()
        self.assertEqual(shoe.remaining, 414)

    def test_simulated_shoe_never_reuses_cards(self):
        for seed in range(30):
            sim = simulate_shoe_with_burn(random.Random(seed))
            hands = sim.hands
            dealt = [sim.burn.exposed] + list(sim.burn.additional)  # burned count as used
            for h in hands:
                dealt += list(h.player_initial) + list(h.banker_initial)
                dealt += [c for c in (h.player_third, h.banker_third) if c]
            self.assertEqual(len(dealt), len(set(dealt)))
            self.assertEqual(len(dealt) + hands[-1].cards_remaining, 416)  # burned + dealt + remaining


if __name__ == "__main__":
    unittest.main()
