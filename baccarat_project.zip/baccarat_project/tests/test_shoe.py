import random
import unittest

from baccarat.shoe import MAX_CARDS_PER_HAND, play_shoe, simulate_shoe
from .helpers import make_shoe


class ShoeTests(unittest.TestCase):
    def test_same_seed_same_shoe(self):
        a = simulate_shoe(random.Random(123))
        b = simulate_shoe(random.Random(123))
        self.assertEqual(a, b)

    def test_different_seeds_differ(self):
        a = [h.result for h in simulate_shoe(random.Random(1))]
        b = [h.result for h in simulate_shoe(random.Random(2))]
        self.assertNotEqual(a, b)

    def test_shoe_stops_when_too_few_cards(self):
        for seed in range(100):
            hands = simulate_shoe(random.Random(seed))
            self.assertLess(hands[-1].cards_remaining, MAX_CARDS_PER_HAND + 6)
            self.assertTrue(60 <= len(hands) <= 95, len(hands))
        # Every hand started with at least 6 cards available.
        hands = simulate_shoe(random.Random(5))
        for h in hands[:-1]:
            self.assertGreaterEqual(h.cards_remaining, MAX_CARDS_PER_HAND - 2)

    def test_scripted_shoe_stops_with_insufficient_cards(self):
        # 11 cards of naturals: hand 1 uses 4 (7 left), hand 2 uses 4 (3 left), stop.
        ranks = ["4", "2", "5", "2"] * 2 + ["K", "K", "K"]
        shoe = make_shoe(ranks, extra=0)
        hands = list(play_shoe(shoe))
        self.assertEqual(len(hands), 2)
        self.assertEqual(shoe.remaining, 3)

    def test_hands_are_yielded_one_at_a_time(self):
        gen = play_shoe(make_shoe(["4", "2", "5", "2"] * 3, extra=0))
        first = next(gen)
        self.assertIn(first.result, "BPT")
        self.assertEqual(first.hand_number, 1)


if __name__ == "__main__":
    unittest.main()
